create database ongmiau;
use ongmiau;
create table usuario (
nome varchar(255),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;

create table blog(
id_artigo int, nome varchar(100), descricao varchar(1000), imagem varchar (100), comentarios varchar(255), email varchar(100));
alter table blog add constraint fk_email foreign key(email) references usuario(email);
