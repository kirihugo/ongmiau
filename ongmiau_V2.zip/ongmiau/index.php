<!DOCTYPE html>
<html lang="pt">

<?php
include 'conexao.php';
include 'modelo\Animal.php';
include 'Repositorio\AnimalRepositorio.php';

$animaisRepositorio = new AnimalRepositorio($conn);
$animais = $animaisRepositorio->listarAnimais();
?>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>ONG MI-AU</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/gc1.png" rel="icon">
  <link href="assets/img/gc1.png" rel="gc">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: DevFolio
  * Updated: Jul 27 2023 with Bootstrap v5.3.1
  * Template URL: https://bootstrapmade.com/devfolio-bootstrap-portfolio-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="index.html">ONG MI-AU</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">Sobre</a></li>
          <li><a class="nav-link scrollto" href="#services">Serviços</a></li>
          <li><a class="nav-link scrollto " href="#work">Trabalho</a></li>
          <li><a class="nav-link scrollto " href="#blog">Exposição</a></li>
          <li><a class="nav-link scrollto" href="#contact">Cadastre-se</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <div id="hero" class="hero route bg-image" style="background-image: url(assets/img/gato4.png)">
    <div class="overlay-itro"></div>
    <div class="hero-content display-table">
      <div class="table-cell">
        <div class="container">
          <!--<p class="display-6 color-d">Hello, world!</p>-->
          <h1 class="hero-title mb-4">ONG MI-AU</h1>
          <p class="hero-subtitle"><span class="typed" data-typed-items="Cachorro, Gato, Porquinho, Piriquito, Furão, Coelho"></span></p>
          <!-- <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#about" role="button">Learn More</a></p> -->
        </div>
      </div>
    </div>
  </div><!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about-mf sect-pt4 route">
      <h1 class="title-a title-box text-center">
        CRIADORES
      </h1>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="box-shadow-full">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-sm-6 col-md-5">
                      <div class="about-img">
                        <img src="assets/img/hugo.jpg" class="img-fluid rounded b-shadow-a" alt="">
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-7">
                      <div class="about-info">
                        <p><span class="title-s">Nome: </span> <span>Kirihugo</span></p>
                        <p><span class="title-s">Profissão: </span> <span>estudante de artes cênicas da USP</span></p>
                        <p><span class="title-s">Email: </span> <span>hugo.santos1@aluno.ifsp.edu.br</span></p>
                        <p><span class="title-s">Telefone: </span> <span>(11) 9 5833-6180</span></p>
                      </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="about-me pt-4 pt-md-0">
                    <div class="title-box-2">
                      <h5 class="title-left">
                        Sobre Mim
                      </h5>
                    </div>
                    <p class="lead">
                      Gosto de verão e gatos.
                    </p>
                    <p class="lead">
                      Amo estudar na USP.
                    <p class="lead">
                     Quero viver intensamente.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="box-shadow-full">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-sm-6 col-md-5">
                      <div class="about-img">
                        <img src="assets/img/amanda.jpg" class="img-fluid rounded b-shadow-a" alt="">
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-7">
                      <div class="about-info">
                        <p><span class="title-s">Nome: </span> <span>Amanda Antero</span></p>
                        <p><span class="title-s">Profissão: </span> <span>estudante de arquitetura na USP</span></p>
                        <p><span class="title-s">Email: </span> <span>amanda.antero@aluno.ifsp.edu.br</span></p>
                        <p><span class="title-s">Telefone: </span> <span>(11) 9 5106-7005</span></p>
                      </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="about-me pt-4 pt-md-0">
                    <div class="title-box-2">
                      <h5 class="title-left">
                        Sobre Mim
                      </h5>
                    </div>
                    <p class="lead">
                     Gosto de gatos e música.
                    </p>
                    <p class="lead">
                     Amo estudar na USP.
                    </p>
                    <p class="lead">
                      Quero ser muito rica e famosa.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End About Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services-mf pt-5 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                Nossos Serviços
              </h3>
              <p class="subtitle-a">
                Esses são os serviços que fornecemos
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="service-box">
              <div class="service-ico">
                <span class="ico-circle"><i class="bi bi-briefcase"></i></span>
              </div>
              <div class="service-content">
                <h3 class="s-title">ADOÇÃO</h3>
                <p class="s-description text-center">
                  A adoção é um processo legal que permite que pessoas ou casais se tornem pais de uma criança que não é biologicamente deles. 
                  Envolve etapas como avaliação de elegibilidade, escolha da agência, treinamento, 
                  busca por uma criança compatível, avaliação de compatibilidade, audiência judicial e cuidado pós-adoção. 
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="service-box">
              <div class="service-ico">
                <span class="ico-circle"><i class="bi bi-card-checklist"></i></span>
              </div>
              <div class="service-content">
                <h2 class="s-title">RECEBE DOAÇÕES</h2>
                <p class="s-description text-center">
                  Uma ONG de adoção pode receber doações financeiras, roupas, alimentos, serviços voluntários, transporte, espaço físico, educação, 
                  parcerias corporativas e apoio na conscientização. 
                  Essas doações são fundamentais para apoiar as crianças em acolhimento para o animalzinho e suas operações no dia a dia.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="service-box">
              <div class="service-ico">
                <span class="ico-circle"><i class="bi bi-bar-chart"></i></span>
              </div>
              <div class="service-content">
                <h2 class="s-title">EXPONHA O SEU PET ADOTADO</h2>
                <p class="s-description text-center">
                  Após adotar seu pet, mande uma ou duas fotos para que possamos postá-lo aqui no site. Ele será exposto para que todos vejam a beleza do pet, 
                  além de mostrar que ele conseguiu ganhar um lar de conforto e amor. 
                  Com isso, mais pessoas poderão ser incentivadas a ver que é possível dar amor e carinho para o seu bichinho.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Services Section -->

    <!-- ======= Counter Section ======= -->
    <div class="section-counter paralax-mf bg-image" style="background-image: url(assets/img/fundo2.jpg)">
      <div class="overlay-mf"></div>
      <div class="container position-relative">
        <div class="row">
          <div class="col-sm-3 col-lg-3">
            <div class="counter-box counter-box pt-4 pt-md-0">
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Counter Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="work" class="portfolio-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                PARA ADOÇÃO
              </h3>
              <p class="subtitle-a">
                Olhe como são fofos e adote-os
              </p>
            </div>
          </div>
        </div>
        <div class="row">

          <?php 
          foreach($animais as $animal);
          ?>

          <div class="col-md-4">
            <div class="work-box">
              <a href="assets/img/cachorro1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox">
                <div class="work-img">
                  <img src="assets/img/cachorro1.jpg" alt="" class="img-fluid">
                </div>
              </a>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Balalaika</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Cachorro</span> / <span class="w-date">18 Set. 2023</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <a href="adote1.html"> <span class="bi bi-plus-circle"></span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="work-box">
              <a href="assets/img/gato1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox">
                <div class="work-img">
                  <img src="assets/img/gato1.jpg" alt="" class="img-fluid">
                </div>
              </a>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Cocada Cristina</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Gato</span> / <span class="w-date">18 Set. 2023</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <a href="adote2.html"> <span class="bi bi-plus-circle"></span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="work-box">
              <a href="assets/img/cachorro2.png" data-gallery="portfolioGallery" class="portfolio-lightbox">
                <div class="work-img">
                  <img src="assets/img/cachorro2.png" alt="" class="img-fluid">
                </div>
              </a>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Bidu</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Cachorro</span> / <span class="w-date">18 Set. 2023</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <a href="adote3.html"> <span class="bi bi-plus-circle"></span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="work-box">
              <a href="assets/img/gato2.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox">
                <div class="work-img">
                  <img src="assets/img/gato2.jpg" alt="" class="img-fluid">
                </div>
              </a>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Geremias</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Gato</span> / <span class="w-date">18 Set. 2023</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <a href="adote4.html"> <span class="bi bi-plus-circle"></span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="work-box">
              <a href="assets/img/cachorro3.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox">
                <div class="work-img">
                  <img src="assets/img/cachorro3.jpg" alt="" class="img-fluid">
                </div>
              </a>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Jurema</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Cachorro</span> / <span class="w-date">18 Set. 2023</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <a href="adote5.html"> <span class="bi bi-plus-circle"></span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="work-box">
              <a href="assets/img/gato3.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox">
                <div class="work-img">
                  <img src="assets/img/gato3.jpg" alt="" class="img-fluid">
                </div>
              </a>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Linguinny Linguiça</h2>
                    <div class="w-more">
                      <span class="w-ctegory">Gato</span> / <span class="w-date">18 Set. 2023</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <a href="adote6.html"> <span class="bi bi-plus-circle"></span></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Testimonials Section ======= -->
    <div class="testimonials paralax-mf bg-image" style="background-image: url(assets/img/fundo4.jpg)">
      <div class="overlay-mf"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-12">

            <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
              <div class="swiper-wrapper">

                <div class="swiper-slide">
                  <div class="testimonial-box">
                  </div>
                </div><!-- End testimonial item -->
              </div>
            </div>

            <!-- <div id="testimonial-mf" class="owl-carousel owl-theme">
          
        </div> -->
          </div>
        </div>
      </div>
    </div><!-- End Testimonials Section -->

    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                Exposição
              </h3>
              <p class="subtitle-a">
               Envie para nós o seu animalzinho
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="card card-blog">
              <div class="card-img">
                <a href="blog-single.html"><img src="assets/img/zara.jpg" alt="" class="img-fluid"></a>
              </div>
              <div class="card-body">
                <div class="card-category-box">
                </div>
                <h3 class="card-title">Zarah</h3>
              </div>
              <div class="card-footer">
                <div class="post-author">
                  <a>
                    <span class="author">Kirihugo.</span>
                  </a>
                </div>
                <div class="post-date">
                  <span class="bi bi-clock"></span> 2019
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card card-blog">
              <div class="card-img">
                <img src="assets/img/zelda.jpg" alt="" class="img-fluid"></a>
              </div>
              <div class="card-body">
                <h3 class="card-title">Zzzelda</h3>
              </div>
              <div class="card-footer">
                <div class="post-author">
                  <a>
                    <img src="assets/img/testimonial-2.jpg" alt="">
                    <span class="author">Kirihugo.</span>
                  </a>
                </div>
                <div class="post-date">
                  <span class="bi bi-clock"></span> 2021
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card card-blog">
              <div class="card-img">
                <img src="assets/img/leon.jpg" alt="" class="img-fluid"></a>
              </div>
              <div class="card-body">
                <h3 class="card-title">Leonardo</h3>
              </div>
              <div class="card-footer">
                <div class="post-author">
                  <a>
                    <img src="assets/img/testimonial-2.jpg" alt="">
                    <span class="author">Amanda</span>
                  </a>
                </div>
                <div class="post-date">
                  <span class="bi bi-clock"></span> 2019
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Blog Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="paralax-mf footer-paralax bg-image sect-mt4 route" style="background-image: url(assets/img/fundo3.jpg)">
      <div class="overlay-mf"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="contact-mf">
              <div id="contact" class="box-shadow-full">
              <body>
<main>
    <section class="container-admin-banner">
        <img src="img/logo-serenatto-horizontal.png" class="logo-admin" alt="logo-serenatto">
        <h1>Cadastro de Usuários</h1>
        <img class= "ornaments" src="img/ornaments-coffee.png" alt="ornaments">
    </section>
    <section class="container-form">
        <form method="post" action="processar-cadastro.php">
            <label for="nome">Nome</label>
            <input type="text" id="nome" name="nome" 
            placeholder="Digite o nome do produto" required>
            
            <label for="email">e-mail</label>
            <input type="email" id="email" name="email" 
            placeholder="Digite seu email" required>

            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" 
            placeholder="Digite uma senha" required>
           
            <label for="confirmarsenha">Confirmar Senha</label>
            <input type="password" id="confirmarsenha" name="confirmarsenha" 
            placeholder="Digite uma senha" required>

            <input type="submit" name="cadastro" class="botao-cadastrar" 
            value="Cadastrar usuario"/>
                              <?php
                                  if(isset($_GET["erro"])){
                                      //echo "erro! senha e confirmar senha não são iguais";
                                  ?>
                                      <label for="erro">Senha e confirmar senha não são iguais</label>
                                  <?php } ?>
                      
                              </form>
                              
                      
                          </section>
                      </main>
                      </body>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="copyright-box">
            <p class="copyright">&copy; Copyright <strong>DevFolio</strong>. All Rights Reserved</p>
            <div class="credits">
              <!--
              All the links in the footer should remain intact.
              You can delete the links only if you purchased the pro version.
              Licensing information: https://bootstrapmade.com/license/
              Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=DevFolio
            -->
              Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/typed.js/typed.umd.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>