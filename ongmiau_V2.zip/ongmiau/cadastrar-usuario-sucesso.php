<!doctype html>
<html lang="pt-br">
<head>
<meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/gc1.png" rel="icon">
  <link href="assets/img/gc1.png" rel="gc">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
    <title>Se cadastre na ONG</title>
</head>
<body>
<main>
    <section class="container-admin-banner">
        <h1>Cadastro realizado com sucesso</h1>
    </section>
    <section class="container-form">
        <form action="login.php" method="post">                      
            <input type="submit" name="login" 
            class="botao-cadastrar" value="login"/>
        </form>

    </section>
</main>
</body>
</html>